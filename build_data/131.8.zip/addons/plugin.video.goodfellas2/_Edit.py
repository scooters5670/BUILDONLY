import xbmcaddon

MainBase = 'https://raw.githubusercontent.com/biglad/BUILDONLY/master/configs/987654321999999.xml'
addon = xbmcaddon.Addon('plugin.video.goodfellas2')