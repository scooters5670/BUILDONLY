# -*- coding: utf-8 -*-
import urllib,re,xbmcgui,xbmcplugin,xbmc,sys,process,requests,os
import xbmcaddon

ADDON_PATH = xbmc.translatePath('special://home/addons/plugin.video.weetv/')
ADDON = xbmcaddon.Addon(id='plugin.video.weetv')
ICON = ADDON_PATH + 'icon.png'
FANART = ADDON_PATH + 'fanart.jpg'
menu_icons = 'http://www.geetee.site/wizchannels/images/icons/'
USERDATA_PATH = xbmc.translatePath('special://home/userdata/addon_data')
ADDON_DATA = os.path.join(USERDATA_PATH,'plugin.video.weetv')
favourites = os.path.join(ADDON_DATA,'favourites')
watched = os.path.join(ADDON_DATA,'watched')
imdb = os.path.join(ADDON_DATA,'imdb')
Dialog = xbmcgui.Dialog()
debug = ADDON.getSetting('debug')

def Movie_Main(url):
    #process.Menu('[B]-----MOVIES-----[/B]','',300,menu_icons + 'movies.png','','','')
    
    process.Menu('Latest Movies','http://www.imdb.com/search/title?languages=en&num_votes=1000,200000&production_status=released&title_type=feature,tv_movie&sort=release_date,desc',209,menu_icons + 'in-theaters.png','','','') 
    process.Menu('Top Rated Recent Movies','http://www.imdb.com/search/title?countries=gb,us&languages=en&num_votes=5000,&title_type=feature&view=advanced',209,menu_icons + 'most-popular.png',FANART,'','','')   
    #process.Menu('Movies by Genre','',202,'','','','')
    process.Menu('Movies by Year','',210,menu_icons + 'years.png','','','')		
    process.Menu('All Time Top 250 Movies','http://www.imdb.com/chart/top',206,menu_icons + 'most-voted.png','','','')
    process.Menu('Search Movies','',207,menu_icons + 'search.png','','','')

    process.setView('movies', 'INFO')
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
    


def search_movies():
    Search_title = xbmcgui.Dialog().input('Search', type=xbmcgui.INPUT_ALPHANUM)
    url = 'http://www.imdb.com/find?ref_=nv_sr_fn&q='+Search_title.replace(' ','+')+'&s=all'
    html = requests.get(url).text
    match = re.compile('<tr class="findResult.+?"> <td class="primary_photo"> <a href=".+?" ><img src="(.+?)" /></a> </td> <td class="result_text"> <a href=".+?" >(.+?)</a>(.+?)</td>').findall(html)
    for image,title,year in match:
        if '<' in year:
            pass
        else:
            if '(TV Series)' in year:
                pass
            else:
                image = image.replace('32,44','174,256').replace('UY67','UY256').replace('UX32','UX175').replace('UY44','UY256')
                if ADDON.getSetting('autoplay')=='true':
                    process.PLAY(title+' '+year,'Movies',1501,image,'','','>'+title+'>'+year+'>')
                else:
                    process.Menu(title+' '+year,'Movies',1501,image,image,'','>'+title+'>'+year+'>')
                process.setView('movies', 'INFO')
    
def Movie_Genre(url):
    html = requests.get('http://www.imdb.com/genre/').text
    
    match = re.compile('<h3><a href="(.+?)">(.+?)<span class="normal">').findall(html)
    for url, name in match:
        url = 'http://www.imdb.com/search/title?genres='+name.replace(' ','').lower()+'&title_type=feature&sort=moviemeter,asc'
        process.Menu(name,url,203,'','','','')
        process.setView('movies', 'INFO')
        
def IMDB_Top250(url):
    html = requests.get(url).text
    film = re.compile('<td class="posterColumn">.+?<img src="(.+?)".+?<td class="titleColumn">(.+?)<a.+?title=".+?" >(.+?)</a>.+?<span class="secondaryInfo">(.+?)</span>',re.DOTALL).findall(html)
    for img,no,title,year in film:
        no = no.replace('\n','').replace('  ','').replace('  ','')
        try:
            img = img.replace('45,67','174,256').replace('UY67','UY256').replace('UX45','UX175')
            extra = '>'+title+'>'+year+'>'
            if ADDON.getSetting('autoplay')=='true':
                process.PLAY(title + ' ' + year,'Movies',1501,img,'','',extra)
            else:
                process.Menu(title + ' ' + year,'Movies',1501,img,img,'',extra)
            process.setView('movies', 'INFO')
        except:
            pass
            
def get_imdb_latest(url):
    html = requests.get(url).content     
    block = re.findall('e" data-tconst="(.+?)Votes:</span>',html,re.DOTALL)
    for blocky in block:
        url = re.findall('href="(.+?)"',str(blocky))[0]
        image = re.findall('loadlate="(.+?)"',str(blocky))[0]
        name = re.findall('<a href="/title.+?alt="(.+?)"',str(blocky),re.DOTALL)[0]
        year = re.findall('unbold">(.+?)</span>',str(blocky))[0]
        length = re.findall('<span class="runtime">(.+?)</span>',str(blocky))[0]      
        desc = re.findall('<p class="text-muted">(.+?)</p>',str(blocky),re.DOTALL)[0]                    
        year = re.sub("[^()0123456789\.]","",year)
        imdb = re.findall('data-tconst="(.+?)"',str(blocky),re.DOTALL)[0] 
        xbmc.log('imdb:'+imdb,xbmc.LOGNOTICE)
        #xbmc.log('length:'+length,xbmc.LOGNOTICE)
        #xbmc.log('desc:'+desc,xbmc.LOGNOTICE)
        
        #####process.Menu(name+' '+year,'http://imdb.com'+url,305,image,'',desc,name.encode('utf-8')+year.encode('utf-8'))
        #process.Menu(name+' '+year,'Movies',1501,image,image,'','>'+name+'>'+year+'>')     
        process.Menu(name+' '+year,'Movies',1501,image,image,length+' '+desc,'>'+name+'>'+year+'>'+imdb+'>','')
        #process.Menu(name+' '+year,'Movies',1501,image,image,length+' '+desc,'>'+name+'>'+year+'>')
        process.setView('movies', 'INFO')

		
		

def BOX_year():
    years = ['2017','2016','2015','2014','2013','2012','2011','2010','2009','2008','2007','2006','2005','2004','2003'
              '2002','2001','2000']
    for year in years:
        url = 'http://imdb.com/search/title?has=technical&moviemeter=,200000&num_votes=1000,&production_status=released&year=%s,%s&title_type=feature,tv_movie&sort=boxoffice_gross_us,desc' %(year,year)
        process.Menu('[B][COLOR white]%s[/COLOR][/B]' %year,url,209,'','','','','')
    xbmc.executebuiltin('Container.SetViewMode(50)') 
        
        
        
        
#################################################################################       
            
        
def IMDB_Grab(url):
#   try:
        List = []
        html = requests.get(url).text   
        match = re.compile('<div class="lister-item-image float-left">.+?<a href="(.+?)".+?<img alt="(.+?)".+?loadlate="(.+?)".+?<span class="lister-item-year text-muted unbold">(.+?)</span>.+?<p class="text-muted">\n(.+?)</p>',re.DOTALL).findall(html)
        for url,name,image,year,desc in match:
            image = image.replace('45,67','174,256').replace('UY67','UY256').replace('UX67','UX175').replace('UY98','UY256').replace('SX54','SX170').replace('54,74','174,256').replace('67,98','174,256')
            try:
                if '(2018)' in year:
                    pass
                else:
                    year = year.replace('(I) ','').replace('II','')
                    if ADDON.getSetting('autoplay')=='true':
                        process.PLAY(name + ' ' + year,'Movies',1501,image,'',desc,'>'+name+'>'+year+'>')
                    else:
                        process.Menu(name + ' ' + year,'Movies',1501,image,image,desc,'>'+name+'>'+year+'>')
                    process.setView('movies', 'INFO')
            except:
                pass
        next_page = re.compile('<a href="(.+?)"\nclass="lister-page-next next-page" ref-marker=adv_nxt>Next &#187;</a>').findall(html)
        for item in next_page:
            if item not in List:
                process.Menu('Next Page','http://imdb.com/search/title'+item,203,'','','','')
                List.append(item)
#   except:
#       pass