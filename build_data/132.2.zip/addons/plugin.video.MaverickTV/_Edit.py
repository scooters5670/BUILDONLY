import xbmcaddon
import base64

MainBase = base64.b64decode ('aHR0cDovL21hdmVyaWNrdHYubmV0L2RhdGEvaG9tZS9ob21lLnhtbA==')
addon = xbmcaddon.Addon('plugin.video.MaverickTV')