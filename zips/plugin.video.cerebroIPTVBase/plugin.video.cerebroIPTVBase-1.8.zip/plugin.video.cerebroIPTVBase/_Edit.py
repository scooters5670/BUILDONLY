import xbmcaddon

MainBase = 'https://raw.githubusercontent.com/biglad/BUILDONLY/master/configs/iptv-links.xml' #'https://dl.dropboxusercontent.com/s/jkxcmi8pyoo97ke/home.txt?dl=0'
addon = xbmcaddon.Addon('plugin.video.cerebroIPTVBase')