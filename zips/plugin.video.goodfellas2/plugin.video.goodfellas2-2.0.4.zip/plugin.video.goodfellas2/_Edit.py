import xbmcaddon

MainBase = 'https://raw.githubusercontent.com/biglad/BUILDONLY/master/configs/sd.xml'
addon = xbmcaddon.Addon('plugin.video.goodfellas2')